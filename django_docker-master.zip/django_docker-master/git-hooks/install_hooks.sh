#!/usr/bin/env bash

cp pre-commit ../.git/hooks/